---
title: Basics
weight: 50
pre: "<b>111. </b>"
chapter: true
---

### Chapter 1

# Basics

Discover what this Hugo theme is all about and the core-concepts behind it.
